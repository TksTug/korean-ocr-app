/**
 * KorScan AI - Main Application Controller
 * Features: Part of Speech (POS), Batch Image OCR Scanning, AI Pronunciation Coach, Word Matching Game, Learning Streak Analytics
 */

class KorScanApp {
    constructor() {
        const saved = localStorage.getItem("KORSCAN_VOCAB_LIST");
        if (saved) {
            try {
                this.vocabularyList = JSON.parse(saved);
            } catch (e) {
                this.vocabularyList = [];
            }
        } else {
            this.vocabularyList = [];
        }

        this.currentFilter = 'all';
        this.searchQuery = '';
        this.batchImages = [];
        this.currentFlashcardIndex = 0;
        this.visibleLimit = 16;

        // Mini Game States
        this.selectedKorean = null;
        this.selectedVietnamese = null;
        this.gameScore = 0;
        this.gameTimer = 0;
        this.gameInterval = null;

        this.initDOM();
        this.bindEvents();
        this.updateStreakData();
        this.renderCategoryChips();
        this.renderVocabularyGrid();
        this.checkAPIKeyStatus();
    }

    saveVocabToStorage() {
        localStorage.setItem("KORSCAN_VOCAB_LIST", JSON.stringify(this.vocabularyList));
        this.updateStreakData();
    }

    updateStreakData() {
        const todayStr = new Date().toISOString().slice(0, 10);
        let streakObj = { lastDate: '', count: 0 };
        const savedStreak = localStorage.getItem("KORSCAN_STREAK");
        
        if (savedStreak) {
            try { streakObj = JSON.parse(savedStreak); } catch(e){}
        }

        if (streakObj.lastDate !== todayStr) {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            const yesterdayStr = yesterday.toISOString().slice(0, 10);

            if (streakObj.lastDate === yesterdayStr) {
                streakObj.count += 1;
            } else if (streakObj.lastDate !== todayStr) {
                streakObj.count = 1;
            }
            streakObj.lastDate = todayStr;
            localStorage.setItem("KORSCAN_STREAK", JSON.stringify(streakObj));
        }

        const streakLabel = document.getElementById('streakLabel');
        const totalWordsLabel = document.getElementById('totalWordsLabel');
        const starredWordsLabel = document.getElementById('starredWordsLabel');

        if (streakLabel) streakLabel.innerHTML = `🔥 Chuỗi học: <b>${streakObj.count || 1} Ngày</b>`;
        if (totalWordsLabel) totalWordsLabel.innerHTML = `📊 Tổng tích lũy: <b>${this.vocabularyList.length} từ</b>`;
        if (starredWordsLabel) starredWordsLabel.innerHTML = `⭐ Từ yêu thích: <b>${this.vocabularyList.filter(w => w.starred).length} từ</b>`;
    }

    initDOM() {
        this.dropzone = document.getElementById('dropzone');
        this.fileInput = document.getElementById('fileInput');
        this.cameraInput = document.getElementById('cameraInput');
        this.btnSelectFile = document.getElementById('btnSelectFile');
        this.btnCamera = document.getElementById('btnCamera');

        this.batchPreviewGrid = document.getElementById('batchPreviewGrid');
        this.previewContainer = document.getElementById('previewContainer');
        this.previewImg = document.getElementById('previewImg');
        this.scanLine = document.getElementById('scanLine');
        this.btnScanAI = document.getElementById('btnScanAI');
        this.aiEngineStatus = document.getElementById('aiEngineStatus');

        this.wordGrid = document.getElementById('wordGrid');
        this.searchInput = document.getElementById('searchInput');
        this.filtersBar = document.getElementById('filtersBar');
        this.wordCountLabel = document.getElementById('wordCountLabel');

        this.btnExportSheet = document.getElementById('btnExportSheet');
        this.btnCopySheet = document.getElementById('btnCopySheet');
        this.btnStudyFlashcards = document.getElementById('btnStudyFlashcards');
        this.btnClearAll = document.getElementById('btnClearAll');

        this.btnConnectGSheet = document.getElementById('btnConnectGSheet');
        this.btnSyncGSheet = document.getElementById('btnSyncGSheet');
        this.gsheetModal = document.getElementById('gsheetModal');
        this.btnCloseGSheet = document.getElementById('btnCloseGSheet');
        this.btnCancelGSheet = document.getElementById('btnCancelGSheet');
        this.btnSaveGSheet = document.getElementById('btnSaveGSheet');
        this.gsheetWebhookInput = document.getElementById('gsheetWebhookInput');

        this.btnOpenGame = document.getElementById('btnOpenGame');
        this.gameModal = document.getElementById('gameModal');
        this.btnCloseGame = document.getElementById('btnCloseGame');
        this.btnRestartGame = document.getElementById('btnRestartGame');
        this.gameKoreanCol = document.getElementById('gameKoreanCol');
        this.gameVietnameseCol = document.getElementById('gameVietnameseCol');
        this.gameScoreLabel = document.getElementById('gameScoreLabel');
        this.gameTimerLabel = document.getElementById('gameTimerLabel');

        this.btnOpenSettings = document.getElementById('btnOpenSettings');
        this.settingsModal = document.getElementById('settingsModal');
        this.btnCloseSettings = document.getElementById('btnCloseSettings');
        this.btnSaveSettings = document.getElementById('btnSaveSettings');
        this.geminiApiKeyInput = document.getElementById('geminiApiKeyInput');

        this.flashcardModal = document.getElementById('flashcardModal');
        this.flashcardBox = document.getElementById('flashcardBox');
        this.flashcardKorean = document.getElementById('flashcardKorean');
        this.flashcardRomaja = document.getElementById('flashcardRomaja');
        this.flashcardVietnamese = document.getElementById('flashcardVietnamese');
        this.flashcardExample = document.getElementById('flashcardExample');
        this.flashcardTopicBadge = document.getElementById('flashcardTopicBadge');
        this.flashcardCounter = document.getElementById('flashcardCounter');
        this.btnPrevCard = document.getElementById('btnPrevCard');
        this.btnNextCard = document.getElementById('btnNextCard');
        this.btnCloseModal = document.getElementById('btnCloseModal');

        this.btnToggleAIChat = document.getElementById('btnToggleAIChat');
        this.aiDrawer = document.getElementById('aiDrawer');
        this.btnCloseAIDrawer = document.getElementById('btnCloseAIDrawer');
        this.aiChatInput = document.getElementById('aiChatInput');
        this.btnSendAIChat = document.getElementById('btnSendAIChat');
        this.aiChatMessages = document.getElementById('aiChatMessages');
    }

    bindEvents() {
        this.dropzone.addEventListener('click', () => this.fileInput.click());
        this.dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            this.dropzone.classList.add('dragover');
        });
        this.dropzone.addEventListener('dragleave', () => this.dropzone.classList.remove('dragover'));
        this.dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            this.dropzone.classList.remove('dragover');
            if (e.dataTransfer.files.length > 0) {
                this.handleMultipleFilesSelect(Array.from(e.dataTransfer.files));
            }
        });

        this.btnSelectFile.addEventListener('click', () => this.fileInput.click());
        this.fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) this.handleMultipleFilesSelect(Array.from(e.target.files));
        });

        this.btnCamera.addEventListener('click', () => this.cameraInput.click());
        this.cameraInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) this.handleMultipleFilesSelect(Array.from(e.target.files));
        });

        this.btnScanAI.addEventListener('click', () => this.performBatchAIScan());

        if (this.btnClearAll) {
            this.btnClearAll.addEventListener('click', () => {
                if (confirm('Bạn có chắc muốn xóa sạch toàn bộ danh sách từ vựng hiện tại?')) {
                    this.vocabularyList = [];
                    this.visibleLimit = 16;
                    this.saveVocabToStorage();
                    this.renderCategoryChips();
                    this.renderVocabularyGrid();
                }
            });
        }

        this.searchInput.addEventListener('input', (e) => {
            this.searchQuery = e.target.value.toLowerCase();
            this.visibleLimit = 16;
            this.renderVocabularyGrid();
        });

        this.btnExportSheet.addEventListener('click', () => window.sheetExporter.exportToCSV(this.filteredWords));
        this.btnCopySheet.addEventListener('click', () => window.sheetExporter.copyForGoogleSheet(this.filteredWords));

        this.btnConnectGSheet.addEventListener('click', () => {
            this.gsheetWebhookInput.value = window.sheetExporter.getWebhookUrl();
            this.gsheetModal.style.display = 'flex';
        });
        this.btnCloseGSheet.addEventListener('click', () => this.gsheetModal.style.display = 'none');
        this.btnCancelGSheet.addEventListener('click', () => this.gsheetModal.style.display = 'none');
        this.btnSaveGSheet.addEventListener('click', () => {
            const url = this.gsheetWebhookInput.value.trim();
            window.sheetExporter.setWebhookUrl(url);
            this.gsheetModal.style.display = 'none';
            alert('✅ Đã lưu kết nối Google Sheet cố định!');
        });

        this.btnSyncGSheet.addEventListener('click', async () => {
            try {
                this.btnSyncGSheet.disabled = true;
                this.btnSyncGSheet.innerText = '⏳ Đang đồng bộ...';
                await window.sheetExporter.syncToLiveGoogleSheet(this.filteredWords, (percent, msg) => {
                    this.btnSyncGSheet.innerText = `⏳ ${msg}`;
                });
                alert('🎉 Đã đồng bộ thành công toàn bộ từ vựng sang Google Sheet cố định của bạn!');
            } catch (err) {
                alert(err.message);
            } finally {
                this.btnSyncGSheet.disabled = false;
                this.btnSyncGSheet.innerText = '📊 Đồng Bộ Google Sheet';
            }
        });

        this.btnOpenGame.addEventListener('click', () => this.openGameModal());
        this.btnCloseGame.addEventListener('click', () => this.closeGameModal());
        this.btnRestartGame.addEventListener('click', () => this.startMatchingGame());

        this.btnOpenSettings.addEventListener('click', () => {
            this.geminiApiKeyInput.value = window.ocrEngine.getApiKey();
            this.settingsModal.style.display = 'flex';
        });
        this.btnCloseSettings.addEventListener('click', () => this.settingsModal.style.display = 'none');
        this.btnSaveSettings.addEventListener('click', () => {
            const key = this.geminiApiKeyInput.value.trim();
            window.ocrEngine.setApiKey(key);
            this.checkAPIKeyStatus();
            this.settingsModal.style.display = 'none';
            alert('✅ Đã lưu Gemini API Key! Trợ lý Chatbot AI đã sẵn sàng trò chuyện cùng bạn!');
        });

        this.btnStudyFlashcards.addEventListener('click', () => this.openFlashcardsModal());
        this.flashcardBox.addEventListener('click', () => this.flashcardBox.classList.toggle('flipped'));
        this.btnPrevCard.addEventListener('click', (e) => {
            e.stopPropagation();
            this.prevFlashcard();
        });
        this.btnNextCard.addEventListener('click', (e) => {
            e.stopPropagation();
            this.nextFlashcard();
        });
        this.btnCloseModal.addEventListener('click', () => this.flashcardModal.style.display = 'none');

        this.btnToggleAIChat.addEventListener('click', () => this.aiDrawer.style.display = 'flex');
        this.btnCloseAIDrawer.addEventListener('click', () => this.aiDrawer.style.display = 'none');
        this.btnSendAIChat.addEventListener('click', () => this.handleAISubmit());
        this.aiChatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.handleAISubmit();
        });
    }

    handleMultipleFilesSelect(files) {
        const imageFiles = files.filter(f => f.type.startsWith('image/'));
        if (imageFiles.length === 0) {
            alert('Vui lòng chọn các file hình ảnh!');
            return;
        }

        let loadedCount = 0;
        imageFiles.forEach(file => {
            const reader = new FileReader();
            reader.onload = (e) => {
                this.batchImages.push(e.target.result);
                loadedCount++;
                if (loadedCount === imageFiles.length) {
                    this.renderBatchPreviews();
                }
            };
            reader.readAsDataURL(file);
        });
    }

    renderBatchPreviews() {
        if (this.batchImages.length === 0) {
            this.batchPreviewGrid.style.display = 'none';
            this.previewContainer.style.display = 'none';
            this.btnScanAI.style.display = 'none';
            return;
        }

        if (this.batchImages.length === 1) {
            this.batchPreviewGrid.style.display = 'none';
            this.previewImg.src = this.batchImages[0];
            this.previewContainer.style.display = 'block';
        } else {
            this.previewContainer.style.display = 'none';
            this.batchPreviewGrid.style.display = 'grid';
            this.batchPreviewGrid.innerHTML = this.batchImages.map((src, idx) => `
                <div class="batch-thumb-item">
                    <img src="${src}" class="batch-thumb-img">
                    <button class="batch-thumb-remove" onclick="app.removeBatchImage(${idx})">✕</button>
                </div>
            `).join('');
        }

        this.btnScanAI.disabled = false;
        this.btnScanAI.style.display = 'flex';
        this.btnScanAI.innerText = `⚡ Bắt đầu Quét Hàng Loạt (${this.batchImages.length} ảnh)`;
    }

    removeBatchImage(index) {
        this.batchImages.splice(index, 1);
        this.renderBatchPreviews();
    }

    async performBatchAIScan() {
        if (this.batchImages.length === 0) return;

        const key = window.ocrEngine.getApiKey();
        if (!key) {
            this.geminiApiKeyInput.value = '';
            this.settingsModal.style.display = 'flex';
            alert('🔑 Bạn chưa dán Gemini API Key! Vui lòng dán API Key của bạn để bóc tách từ vựng.');
            return;
        }

        this.btnScanAI.disabled = true;
        this.scanLine.style.display = 'block';

        let totalNewWords = 0;
        const totalImages = this.batchImages.length;

        for (let i = 0; i < totalImages; i++) {
            const imgSrc = this.batchImages[i];
            this.btnScanAI.innerText = `⏳ Đang quét ảnh ${i + 1}/${totalImages}...`;

            try {
                const rawText = await window.ocrEngine.recognizeKoreanText(imgSrc, (percent, msg) => {
                    this.btnScanAI.innerText = `⏳ Ảnh ${i + 1}/${totalImages}: ${msg} (${percent}%)`;
                });

                const newWords = await window.aiService.analyzeAndCategorize(rawText);

                for (const nw of newWords) {
                    const existingIdx = this.vocabularyList.findIndex(w => w.korean === nw.korean);
                    if (existingIdx >= 0) {
                        this.vocabularyList[existingIdx] = nw;
                    } else {
                        this.vocabularyList.unshift(nw);
                        totalNewWords++;
                    }
                }
            } catch (err) {
                console.error(`Lỗi bóc tách ảnh ${i + 1}:`, err);
            }
        }

        this.saveVocabToStorage();
        this.renderCategoryChips();
        this.renderVocabularyGrid();
        alert(`🎉 Đã quét xong hàng loạt ${totalImages} trang ảnh! Thêm mới/cập nhật thành công ${totalNewWords} từ vựng vào bảng!`);

        this.batchImages = [];
        this.renderBatchPreviews();
        this.scanLine.style.display = 'none';
    }

    renderCategoryChips() {
        const labelSet = new Set();
        this.vocabularyList.forEach(w => {
            if (w.topic) {
                const label = window.sheetExporter.getTopicLabel(w.topic).trim();
                labelSet.add(label);
            }
        });

        const labels = Array.from(labelSet);

        let html = `<button class="chip ${this.currentFilter === 'all' ? 'active' : ''}" data-category="all">🌐 Tất cả chủ đề</button>`;
        html += `<button class="chip ${this.currentFilter === 'starred' ? 'active' : ''}" data-category="starred">⭐ Từ yêu thích</button>`;

        labels.forEach(label => {
            html += `<button class="chip ${this.currentFilter === label ? 'active' : ''}" data-category="${label}">${label}</button>`;
        });

        this.filtersBar.innerHTML = html;

        const chips = this.filtersBar.querySelectorAll('.chip');
        chips.forEach(chip => {
            chip.addEventListener('click', () => {
                chips.forEach(c => c.classList.remove('active'));
                chip.classList.add('active');
                this.currentFilter = chip.getAttribute('data-category');
                this.visibleLimit = 16;
                this.renderVocabularyGrid();
            });
        });
    }

    checkAPIKeyStatus() {
        const key = window.ocrEngine.getApiKey();
        if (key) {
            this.aiEngineStatus.innerText = '⚡ Gemini 1.5 Flash API Connected';
            this.aiEngineStatus.style.color = '#10B981';
        } else {
            this.aiEngineStatus.innerText = '⚙️ Nhấp "Cấu Hình API AI" để bóc tách 100% ảnh thực';
            this.aiEngineStatus.style.color = '#F59E0B';
        }
    }

    get filteredWords() {
        return this.vocabularyList.filter(w => {
            const wordTopicLabel = window.sheetExporter.getTopicLabel(w.topic).trim();
            const matchesCategory = this.currentFilter === 'all' || 
                (this.currentFilter === 'starred' && w.starred) || 
                wordTopicLabel === this.currentFilter ||
                w.topic === this.currentFilter;

            const matchesSearch = !this.searchQuery || 
                w.korean.toLowerCase().includes(this.searchQuery) ||
                w.vietnamese.toLowerCase().includes(this.searchQuery) ||
                (w.pos && w.pos.toLowerCase().includes(this.searchQuery)) ||
                w.romaja.toLowerCase().includes(this.searchQuery);

            return matchesCategory && matchesSearch;
        });
    }

    getPosClass(pos) {
        if (!pos) return 'pos-noun';
        const lower = pos.toLowerCase();
        if (lower.includes('động') || lower.includes('verb')) return 'pos-verb';
        if (lower.includes('tính') || lower.includes('adj')) return 'pos-adj';
        if (lower.includes('phó') || lower.includes('trạng') || lower.includes('adv')) return 'pos-adv';
        return 'pos-noun';
    }

    renderVocabularyGrid() {
        const allFiltered = this.filteredWords;
        this.wordCountLabel.innerText = `(${allFiltered.length} từ vựng)`;

        if (allFiltered.length === 0) {
            this.wordGrid.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📝</div>
                    <h3>Chưa có từ vựng nào trong danh mục này</h3>
                    <p>Hãy chọn ảnh mới và bấm nút màu xanh <b>"⚡ Bắt đầu Quét Hàng Loạt"</b> để bóc tách & lưu tự động nhé!</p>
                </div>
            `;
            return;
        }

        const visibleWords = allFiltered.slice(0, this.visibleLimit);
        const remainingCount = allFiltered.length - visibleWords.length;

        let gridHtml = visibleWords.map(w => `
            <div class="word-card">
                <div class="word-header">
                    <div>
                        <div class="word-korean">${w.korean}</div>
                        <div class="word-romaja">[${w.romaja}]</div>
                    </div>
                    <div class="card-actions">
                        <button class="action-icon star ${w.starred ? 'active' : ''}" onclick="app.toggleStar('${w.id}')">★</button>
                        <button class="action-icon mic" title="Thu âm chấm điểm phát âm AI" onclick="app.testPronunciation('${w.korean}', this)">🎙️</button>
                        <button class="action-icon" onclick="app.speakKorean('${w.korean}')">🔊</button>
                        <button class="action-icon" onclick="app.deleteWord('${w.id}')">🗑️</button>
                    </div>
                </div>
                <div class="word-vietnamese">👉 ${w.vietnamese}</div>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 4px;">
                    <span class="pos-badge ${this.getPosClass(w.pos)}">${w.pos || 'Danh từ'}</span>
                    <span class="topic-badge badge-daily">${window.sheetExporter.getTopicLabel(w.topic)}</span>
                </div>
            </div>
        `).join('');

        if (remainingCount > 0) {
            gridHtml += `
                <div class="load-more-container">
                    <button class="btn btn-soft" style="padding: 10px 24px; font-size: 14px;" onclick="app.loadMoreWords()">
                        👇 Xem Thêm ${Math.min(16, remainingCount)} Từ Vựng Nữa (Còn ${remainingCount} từ)
                    </button>
                </div>
            `;
        }

        this.wordGrid.innerHTML = gridHtml;
    }

    loadMoreWords() {
        this.visibleLimit += 16;
        this.renderVocabularyGrid();
    }

    testPronunciation(targetKorean, btnElem) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            alert('⚠️ Trình duyệt của bạn không hỗ trợ tính năng nhận diện giọng nói SpeechRecognition!');
            return;
        }

        const recognition = new SpeechRecognition();
        recognition.lang = 'ko-KR';
        recognition.interimResults = false;
        recognition.maxAlternatives = 3;

        btnElem.classList.add('recording');
        btnElem.innerText = '🔴';

        recognition.onresult = (event) => {
            btnElem.classList.remove('recording');
            btnElem.innerText = '🎙️';

            const spokenText = event.results[0][0].transcript.trim();
            const cleanTarget = targetKorean.replace(/[\s\?\.\!]/g, '');
            const cleanSpoken = spokenText.replace(/[\s\?\.\!]/g, '');

            let score = 0;
            if (cleanSpoken === cleanTarget) {
                score = 100;
            } else if (cleanTarget.includes(cleanSpoken) || cleanSpoken.includes(cleanTarget)) {
                score = 75;
            } else {
                score = Math.max(30, 100 - (Math.abs(cleanTarget.length - cleanSpoken.length) * 20));
            }

            if (score >= 90) {
                alert(`🌟 CHẤM ĐIỂM PHÁT ÂM: ${score}%\n🗣️ Giọng của bạn: "${spokenText}"\n👉 Kết quả: Phát âm xuất sắc chuẩn 100% giọng Hàn Quốc!`);
            } else if (score >= 60) {
                alert(`👍 CHẤM ĐIỂM PHÁT ÂM: ${score}%\n🗣️ Giọng của bạn: "${spokenText}"\n👉 Kết quả: Phát âm khá tốt! Hãy nhấn nút 🔊 nghe lại và phát âm rõ hơn nhé.`);
            } else {
                alert(`💪 CHẤM ĐIỂM PHÁT ÂM: ${score}%\n🗣️ Giọng của bạn: "${spokenText}" (Từ chuẩn: "${targetKorean}")\n👉 Cố lên! Hãy nhấn nút 🔊 nghe mẫu và thử lại nhé.`);
            }
        };

        recognition.onerror = (err) => {
            btnElem.classList.remove('recording');
            btnElem.innerText = '🎙️';
            alert(`Lỗi nhận diện micro: ${err.error || 'Vui lòng cho phép truy cập Micro!'}`);
        };

        recognition.onend = () => {
            btnElem.classList.remove('recording');
            btnElem.innerText = '🎙️';
        };

        recognition.start();
    }

    openGameModal() {
        if (this.vocabularyList.length < 4) {
            alert('⚠️ Bạn cần bóc tách ít nhất 4 từ vựng để bắt đầu Mini-Game Nối Từ!');
            return;
        }
        this.gameModal.style.display = 'flex';
        this.startMatchingGame();
    }

    closeGameModal() {
        this.gameModal.style.display = 'none';
        if (this.gameInterval) clearInterval(this.gameInterval);
    }

    startMatchingGame() {
        if (this.gameInterval) clearInterval(this.gameInterval);
        this.selectedKorean = null;
        this.selectedVietnamese = null;
        this.gameScore = 0;
        this.gameTimer = 0;
        this.gameScoreLabel.innerText = `🏆 Điểm số: 0`;
        this.gameTimerLabel.innerText = `⏱️ Thời gian: 0s`;

        this.gameInterval = setInterval(() => {
            this.gameTimer++;
            this.gameTimerLabel.innerText = `⏱️ Thời gian: ${this.gameTimer}s`;
        }, 1000);

        const shuffled = [...this.vocabularyList].sort(() => 0.5 - Math.random());
        const gameWords = shuffled.slice(0, 4);

        const koreanList = [...gameWords].sort(() => 0.5 - Math.random());
        const vietList = [...gameWords].sort(() => 0.5 - Math.random());

        this.gameKoreanCol.innerHTML = koreanList.map(w => `
            <div class="game-card" data-id="${w.id}" data-korean="${w.korean}" onclick="app.selectKoreanCard(this)">
                🇰🇷 ${w.korean}
            </div>
        `).join('');

        this.gameVietnameseCol.innerHTML = vietList.map(w => `
            <div class="game-card" data-id="${w.id}" data-vietnamese="${w.vietnamese}" onclick="app.selectVietnameseCard(this)">
                🇻🇳 ${w.vietnamese}
            </div>
        `).join('');
    }

    selectKoreanCard(elem) {
        if (elem.classList.contains('matched')) return;
        this.gameKoreanCol.querySelectorAll('.game-card').forEach(c => c.classList.remove('selected'));
        elem.classList.add('selected');
        this.selectedKorean = elem;
        this.checkMatchPair();
    }

    selectVietnameseCard(elem) {
        if (elem.classList.contains('matched')) return;
        this.gameVietnameseCol.querySelectorAll('.game-card').forEach(c => c.classList.remove('selected'));
        elem.classList.add('selected');
        this.selectedVietnamese = elem;
        this.checkMatchPair();
    }

    checkMatchPair() {
        if (this.selectedKorean && this.selectedVietnamese) {
            const idKor = this.selectedKorean.getAttribute('data-id');
            const idViet = this.selectedVietnamese.getAttribute('data-id');

            if (idKor === idViet) {
                this.selectedKorean.classList.remove('selected');
                this.selectedVietnamese.classList.remove('selected');
                this.selectedKorean.classList.add('matched');
                this.selectedVietnamese.classList.add('matched');

                this.selectedKorean = null;
                this.selectedVietnamese = null;
                this.gameScore += 25;
                this.gameScoreLabel.innerText = `🏆 Điểm số: ${this.gameScore}`;

                if (this.gameScore === 100) {
                    clearInterval(this.gameInterval);
                    setTimeout(() => {
                        alert(`🎉 XUẤT SẮC! BẠN ĐÃ THẮNG TRÒ CHƠI NỐI TỪ!\n⏱️ Thời gian hoàn thành: ${this.gameTimer} giây!\n🏆 Điểm tuyệt đối: 100 Điểm!`);
                    }, 200);
                }
            } else {
                const kor = this.selectedKorean;
                const viet = this.selectedVietnamese;
                kor.classList.add('wrong');
                viet.classList.add('wrong');

                setTimeout(() => {
                    kor.classList.remove('wrong', 'selected');
                    viet.classList.remove('wrong', 'selected');
                }, 400);

                this.selectedKorean = null;
                this.selectedVietnamese = null;
            }
        }
    }

    toggleStar(id) {
        const word = this.vocabularyList.find(w => w.id === id);
        if (word) {
            word.starred = !word.starred;
            this.saveVocabToStorage();
            this.renderVocabularyGrid();
        }
    }

    deleteWord(id) {
        if (confirm('Bạn có chắc muốn xóa từ vựng này khỏi danh sách?')) {
            this.vocabularyList = this.vocabularyList.filter(w => w.id !== id);
            this.saveVocabToStorage();
            this.renderCategoryChips();
            this.renderVocabularyGrid();
        }
    }

    speakKorean(text) {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'ko-KR';
            window.speechSynthesis.speak(utterance);
        } else {
            alert('Trình duyệt của bạn không hỗ trợ phát âm tự động!');
        }
    }

    openFlashcardsModal() {
        const words = this.filteredWords;
        if (words.length === 0) {
            alert('Không có từ vựng nào trong danh sách để ôn tập!');
            return;
        }
        this.currentFlashcardIndex = 0;
        this.renderFlashcard();
        this.flashcardModal.style.display = 'flex';
    }

    renderFlashcard() {
        const words = this.filteredWords;
        const current = words[this.currentFlashcardIndex];
        if (!current) return;

        this.flashcardBox.classList.remove('flipped');
        this.flashcardKorean.innerText = current.korean;
        this.flashcardRomaja.innerText = `[${current.romaja}]`;
        this.flashcardVietnamese.innerText = current.vietnamese;
        this.flashcardExample.innerText = current.example;
        this.flashcardTopicBadge.innerText = window.sheetExporter.getTopicLabel(current.topic);
        this.flashcardTopicBadge.className = `topic-badge badge-daily`;

        this.flashcardCounter.innerText = `${this.currentFlashcardIndex + 1} / ${words.length}`;
    }

    prevFlashcard() {
        const words = this.filteredWords;
        this.currentFlashcardIndex = (this.currentFlashcardIndex - 1 + words.length) % words.length;
        this.renderFlashcard();
    }

    nextFlashcard() {
        const words = this.filteredWords;
        this.currentFlashcardIndex = (this.currentFlashcardIndex + 1) % words.length;
        this.renderFlashcard();
    }

    formatMarkdown(text) {
        if (!text) return '';
        return text
            .replace(/\\n/g, '\n')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/\*\*(.*?)\*\*/g, '<b>$1</b>')
            .replace(/\*(.*?)\*/g, '<i>$1</i>')
            .replace(/`([^`]+)`/g, '<code>$1</code>')
            .replace(/\n/g, '<br/>');
    }

    async handleAISubmit() {
        const text = this.aiChatInput.value.trim();
        if (!text) return;

        this.appendChatMessage('user', text);
        this.aiChatInput.value = '';

        const loadingId = this.appendChatMessage('bot', '⏳ Thầy giáo AI Gemini đang soạn câu trả lời...');
        const aiResponse = await window.aiService.askAITutor(text, this.vocabularyList);
        
        const loadingElem = document.getElementById(loadingId);
        if (loadingElem) {
            loadingElem.innerHTML = this.formatMarkdown(aiResponse);
        }
    }

    appendChatMessage(sender, text) {
        const msgId = 'msg_' + Math.random().toString(36).substr(2, 9);
        const div = document.createElement('div');
        div.id = msgId;
        div.style.padding = '10px 14px';
        div.style.borderRadius = '12px';
        div.style.marginBottom = '10px';
        div.style.fontSize = '13px';
        div.style.lineHeight = '1.5';

        if (sender === 'user') {
            div.style.background = 'rgba(56, 189, 248, 0.2)';
            div.style.color = '#F9FAFB';
            div.style.alignSelf = 'flex-end';
            div.style.marginLeft = '30px';
        } else {
            div.style.background = 'rgba(30, 41, 59, 0.8)';
            div.style.color = '#E2E8F0';
            div.style.border = '1px solid rgba(255, 255, 255, 0.08)';
            div.style.marginRight = '30px';
        }

        div.innerHTML = this.formatMarkdown(text);
        this.aiChatMessages.appendChild(div);
        this.aiChatMessages.scrollTop = this.aiChatMessages.scrollHeight;

        return msgId;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.app = new KorScanApp();
});
