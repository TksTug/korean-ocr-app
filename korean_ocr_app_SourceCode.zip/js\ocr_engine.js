/**
 * KorScan AI - Universal Multimodal Gemini Vision OCR Engine
 * Supports Part of Speech (POS), Batch Scanning & Dynamic Topic Classification
 */

class OCREngine {
    constructor() {
        const defaultKey = "AQ.Ab8RN6J9o3-ZpVQ-a551gtDdn9aIN9IP6Ha4Du4niwprQW7J2w";
        let savedKey = localStorage.getItem("KORSCAN_GEMINI_API_KEY");
        
        if (!savedKey || savedKey.includes("...") || savedKey.length < 20) {
            savedKey = defaultKey;
            localStorage.setItem("KORSCAN_GEMINI_API_KEY", defaultKey);
        }

        this.geminiApiKey = savedKey;
    }

    setApiKey(key) {
        this.geminiApiKey = (key || "").trim().replace(/[\s\r\n\t\\'"]/g, '');
        localStorage.setItem("KORSCAN_GEMINI_API_KEY", this.geminiApiKey);
    }

    getApiKey() {
        return this.geminiApiKey;
    }

    async compressImage(imageSrc) {
        return new Promise((resolve) => {
            const img = new Image();
            img.crossOrigin = "anonymous";
            img.onload = () => {
                const canvas = document.createElement("canvas");
                const ctx = canvas.getContext("2d");
                
                const maxDim = 1200;
                let width = img.naturalWidth || img.width;
                let height = img.naturalHeight || img.height;

                if (width > maxDim || height > maxDim) {
                    if (width > height) {
                        height = Math.round((height * maxDim) / width);
                        width = maxDim;
                    } else {
                        width = Math.round((width * maxDim) / height);
                        height = maxDim;
                    }
                }

                canvas.width = width;
                canvas.height = height;

                ctx.imageSmoothingEnabled = true;
                ctx.imageSmoothingQuality = "high";
                ctx.drawImage(img, 0, 0, width, height);

                resolve(canvas.toDataURL("image/jpeg", 0.85));
            };
            img.onerror = () => resolve(imageSrc);
            img.src = imageSrc;
        });
    }

    /**
     * Send image to Gemini Vision API with Part of Speech (POS) & Dynamic Topic Classification
     */
    async recognizeKoreanText(imageSrc, progressCallback) {
        if (progressCallback) progressCallback(15, "Đang tối ưu dung lượng ảnh...");

        const cleanKey = (this.geminiApiKey || "AQ.Ab8RN6J9o3-ZpVQ-a551gtDdn9aIN9IP6Ha4Du4niwprQW7J2w").trim().replace(/[\s\r\n\t\\'"]/g, '');
        const compressedSrc = await this.compressImage(imageSrc);
        const cleanBase64 = compressedSrc.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");

        const promptText = `Bạn là hệ thống AI Vision bóc tách văn bản Tiếng Hàn (Hangul) chuyên nghiệp.
Nhiệm vụ duy nhất của bạn:
1. Đọc và bóc tách NGUYÊN VĂN TẤT CẢ các từ/cụm từ tiếng Hàn (Hangul) thực sự ghi trong bức ảnh này.
2. Với mỗi từ đọc được trong ảnh, hãy cung cấp:
   - Phiên âm Romaja.
   - Dịch nghĩa tiếng Việt chuẩn xác.
   - PHÂN LOẠI TỪ LOẠI ("pos"): "Danh từ", "Động từ", "Tính từ", "Phó từ", "Trạng từ", "Thán từ"...
   - PHÂN LOẠI CHỦ ĐỀ ("topic"): Tự chọn hoặc TỰ TẠO MỚI tên chủ đề kèm Icon (ví dụ: '🌤️ Thời tiết', '🍽️ Nhà hàng', '💊 Y tế', '🏠 Gia đình', '💼 Công việc', '💬 Giao tiếp'...).
3. Tuyệt đối KHÔNG tự tạo ra các từ không xuất hiện trong bức ảnh này.

Trả về DUY NHẤT 1 mảng JSON thuần túy (JSON Array):
[
  {
    "korean": "Từ tiếng Hàn nguyên văn trong ảnh",
    "romaja": "Phiên âm Romaja",
    "vietnamese": "Dịch nghĩa Tiếng Việt chuẩn xác",
    "pos": "Từ loại (Danh từ, Động từ, Tính từ, Phó từ...)",
    "topic": "Tên chủ đề ngắn gọn kèm Icon",
    "example": "Câu ví dụ tiếng Hàn ngắn kèm dịch tiếng Việt"
  }
]`;

        const models = ["gemini-flash-latest", "gemini-2.0-flash"];
        let lastErrorText = "";

        for (let i = 0; i < models.length; i++) {
            const model = models[i];
            if (progressCallback) progressCallback(40 + (i * 25), `Gemini AI (${model}) đang bóc tách 100% ảnh thực...`);

            try {
                const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${cleanKey}`;
                const payload = {
                    contents: [{
                        parts: [
                            { text: promptText },
                            { inline_data: { mime_type: "image/jpeg", data: cleanBase64 } }
                        ]
                    }]
                };

                const resp = await fetch(url, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(payload)
                });

                if (resp.ok) {
                    const data = await resp.json();
                    const jsonText = data.candidates?.[0]?.content?.parts?.[0]?.text;
                    if (jsonText) {
                        const arrayMatch = jsonText.match(/\[\s*\{[\s\S]*\}\s*\]/);
                        const cleanJson = arrayMatch ? arrayMatch[0] : jsonText.replace(/```json/gi, "").replace(/```/g, "").trim();
                        
                        try {
                            const parsedArray = JSON.parse(cleanJson);
                            if (Array.isArray(parsedArray)) {
                                if (progressCallback) progressCallback(100, "Bóc tách & Phân loại từ loại thành công!");
                                return parsedArray;
                            }
                        } catch (parseErr) {
                            console.warn(`Lỗi parse JSON (${model}):`, parseErr);
                        }
                    }
                } else {
                    const errData = await resp.text();
                    console.warn(`Lỗi Gemini API (${model} - ${resp.status}):`, errData);
                    try {
                        const parsedErr = JSON.parse(errData);
                        lastErrorText = parsedErr.error?.message || `Mã lỗi HTTP ${resp.status}`;
                    } catch (e) {
                        lastErrorText = `Google API trả về mã lỗi HTTP ${resp.status}`;
                    }

                    if (resp.status === 429) {
                        if (progressCallback) progressCallback(75, "Đang chờ 3s trước khi bóc tách...");
                        await new Promise(r => setTimeout(r, 3200));
                    }
                }
            } catch (err) {
                console.warn(`Lỗi kết nối ${model}:`, err);
                lastErrorText = err.message;
            }
        }

        throw new Error(`❌ Lỗi kết nối Google Gemini API:\n"${lastErrorText}"`);
    }
}

window.ocrEngine = new OCREngine();
