/**
 * KorScan AI - Google Sheet Exporter & Live Webhook Direct Sync Engine
 */

class SheetExporter {
    constructor() {
        this.webhookUrl = localStorage.getItem("KORSCAN_GSHEET_WEBHOOK_URL") || "";
    }

    setWebhookUrl(url) {
        this.webhookUrl = (url || "").trim();
        localStorage.setItem("KORSCAN_GSHEET_WEBHOOK_URL", this.webhookUrl);
    }

    getWebhookUrl() {
        return this.webhookUrl;
    }

    /**
     * Live sync vocabulary directly into a fixed Google Sheet via Google Apps Script Webhook
     */
    async syncToLiveGoogleSheet(wordsList, progressCallback) {
        const url = this.getWebhookUrl();
        if (!url) {
            throw new Error("⚠️ Bạn chưa dán Link Webhook Google Sheet! Vui lòng bấm '🔗 Kết Nối Google Sheet' để dán link.");
        }

        if (!wordsList || wordsList.length === 0) {
            throw new Error("Không có từ vựng nào trong danh sách để đồng bộ!");
        }

        if (progressCallback) progressCallback(30, "Đang kết nối tới Google Sheet cố định...");

        const payload = wordsList.map(w => ({
            korean: w.korean,
            romaja: w.romaja,
            vietnamese: w.vietnamese,
            topic: this.getTopicLabel(w.topic),
            example: w.example,
            date: w.date || new Date().toLocaleDateString('vi-VN')
        }));

        try {
            const resp = await fetch(url, {
                method: "POST",
                mode: "no-cors", // Google Apps Script redirect mode
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            if (progressCallback) progressCallback(100, "Đã gửi dữ liệu sang Google Sheet thành công!");
            return true;
        } catch (err) {
            console.error("Lỗi đồng bộ Google Sheet:", err);
            throw new Error(`Lỗi kết nối Google Sheet: ${err.message}`);
        }
    }

    exportToCSV(wordsList) {
        if (!wordsList || wordsList.length === 0) {
            alert("Không có từ vựng nào để xuất file!");
            return;
        }

        let csvContent = "\uFEFF"; // UTF-8 BOM for Excel
        csvContent += "Từ Tiếng Hàn,Phiên Âm Romaja,Dịch Tiếng Việt,Nhóm Chủ Đề,Ví Dụ,Ngày Thêm\n";

        wordsList.forEach(w => {
            const korean = `"${(w.korean || '').replace(/"/g, '""')}"`;
            const romaja = `"${(w.romaja || '').replace(/"/g, '""')}"`;
            const vietnamese = `"${(w.vietnamese || '').replace(/"/g, '""')}"`;
            const topic = `"${this.getTopicLabel(w.topic)}"`;
            const example = `"${(w.example || '').replace(/"/g, '""')}"`;
            const date = `"${w.date || ''}"`;

            csvContent += `${korean},${romaja},${vietnamese},${topic},${example},${date}\n`;
        });

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", `TuVung_TiengHan_${new Date().toISOString().slice(0, 10)}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    copyForGoogleSheet(wordsList) {
        if (!wordsList || wordsList.length === 0) {
            alert("Không có từ vựng nào để copy!");
            return;
        }

        let tsvContent = "Từ Tiếng Hàn\tPhiên Âm Romaja\tDịch Tiếng Việt\tNhóm Chủ Đề\tVí Dụ\tNgày Thêm\n";

        wordsList.forEach(w => {
            tsvContent += `${w.korean}\t${w.romaja}\t${w.vietnamese}\t${this.getTopicLabel(w.topic)}\t${w.example || ''}\t${w.date || ''}\n`;
        });

        navigator.clipboard.writeText(tsvContent).then(() => {
            alert("✅ Đã copy xong! Bây giờ bạn chỉ cần mở Google Sheet ra và bấm Ctrl + V để dán toàn bộ dữ liệu vào!");
        }).catch(err => {
            console.error("Lỗi copy:", err);
            alert("Không thể copy tự động, vui lòng kiểm tra quyền trình duyệt!");
        });
    }

    getTopicLabel(topic) {
        const labels = {
            weather: "🌤️ Thời tiết - Thiên nhiên",
            restaurant: "🍽️ Nhà hàng - Ẩm thực",
            hotel: "🏨 Khách sạn - Du lịch",
            shopping: "🛍️ Mua sắm",
            daily: "💬 Giao tiếp hàng ngày",
            work: "💼 Công việc - Học tập",
            transport: "🚗 Giao thông"
        };
        return labels[topic] || "💬 Giao tiếp hàng ngày";
    }
}

window.sheetExporter = new SheetExporter();
